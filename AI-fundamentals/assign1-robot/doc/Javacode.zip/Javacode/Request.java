import java.util.Map;

public interface Request
{
   public Map<String, Object> getData();
   public String getPath();
}

